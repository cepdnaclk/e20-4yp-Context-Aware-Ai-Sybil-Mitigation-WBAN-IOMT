# Quick Reference Card: Sybil Detection Decision Guide

## 🎯 One-Page Decision Guide

### Step 1: Answer These 6 Questions (2 minutes)

```
1. Do you have labeled Sybil attack data?           [ ] YES [ ] NO
2. Must inference be <5ms (edge device)?            [ ] YES [ ] NO
3. Is detecting novel attacks important?            [ ] YES [ ] NO
4. Are temporal patterns important?                 [ ] YES [ ] NO
5. Can you wait 3+ weeks for maximum accuracy?      [ ] YES [ ] NO
6. Is this a critical healthcare system?            [ ] YES [ ] NO
```

### Step 2: Find Your Scenario

```
SCENARIO A: High Accuracy (Hospital Grade)
├─ All 6 questions mostly YES
├─ Has labeled data, accuracy critical, time available
├─ Best Model: Gradient Boosting + Ensemble
├─ Expected: 95%+ F1, 2-3 weeks
└─ Use if: Hospital WBAN, life-critical monitoring

SCENARIO B: Fast Edge Deployment
├─ Question 2 is YES (must be <5ms)
├─ Questions 1 & 3 can be YES or NO
├─ Best Model: Random Forest (lightweight)
├─ Expected: 90% F1, <5ms inference, 1 week
└─ Use if: ESP32 device, IoT wearable, real-time needed

SCENARIO C: Unknown Attacks (No Labels)
├─ Question 1 is NO (no labeled attacks)
├─ Question 3 is YES (detect novel attacks)
├─ Best Model: Isolation Forest
├─ Expected: 85% F1, works without labels, 1-2 weeks
└─ Use if: New deployment, evolving threats, no historical data

SCENARIO D: Temporal Patterns Matter
├─ Question 4 is YES (temporal important)
├─ Questions 1 or 5 are YES
├─ Best Model: LSTM + Ensemble
├─ Expected: 92-95% F1, pattern learning, 2-4 weeks
└─ Use if: Behavior changes gradual, sequences important

SCENARIO E: Maximum Robustness (Critical)
├─ Question 6 is YES (life-critical)
├─ Multiple models needed, complexity acceptable
├─ Best Model: Ensemble (RF + GB + SVM + Isolation F + LSTM)
├─ Expected: 96%+ F1, graceful degradation, 4-6 weeks
└─ Use if: ICU monitoring, defense, zero-failure tolerance
```

---

## 📊 Scenario Comparison Table

| Aspect | Scenario A | Scenario B | Scenario C | Scenario D | Scenario E |
|--------|-----------|-----------|-----------|-----------|-----------|
| **Data Req.** | Labeled | Labeled | Any | Any | Labeled |
| **Speed** | OK | <5ms ⭐ | OK | Slow | OK |
| **Accuracy** | 95% ⭐⭐⭐⭐⭐ | 90% | 85% | 92% | 96% ⭐⭐⭐⭐⭐ |
| **Model** | GB+Ens | RF | IsoForest | LSTM | Ensemble |
| **Time** | 2-3 wk | 1 wk | 1-2 wk | 2-4 wk | 4-6 wk |
| **Complexity** | Medium | Low | Low | High | Very High |
| **Novel Attacks** | ❌ | ❌ | ✅ | ✅ | ✅ |
| **Interpretable** | ✅ | ✅ | ❌ | ❌ | ✅ |

---

## 🛠️ Quick Implementation Template

### **For Your Chosen Scenario:**

```python
# [SCENARIO B EXAMPLE - Fast Edge Device]

from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split

# 1. LOAD DATA
X, y = load_your_data()  # Your features and labels

# 2. SPLIT (80-20 train-test)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42
)

# 3. SCALE (optional for tree-based)
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# 4. TRAIN (lightweight for edge)
model = RandomForestClassifier(
    n_estimators=150,      # Fast: <200 trees
    max_depth=10,          # Shallow: <15
    class_weight='balanced',
    random_state=42
)
model.fit(X_train, y_train)

# 5. EVALUATE
from sklearn.metrics import classification_report, f1_score
y_pred = model.predict(X_test)
print(classification_report(y_test, y_pred))
print(f"F1-Score: {f1_score(y_test, y_pred):.2%}")

# 6. PREDICT NEW DATA
y_prob = model.predict_proba(X_new)[:, 1]  # Probability
is_sybil = (y_prob > 0.5).astype(int)      # Classification
```

---

## ⏱️ Week-by-Week Plan (Pick Your Scenario)

### **Scenario A (3 weeks)**
```
Week 1:
  ☐ Load data, basic EDA
  ☐ Train Random Forest baseline (should get ~90%)
  ☐ Implement class weighting
  
Week 2:
  ☐ Apply SMOTE oversampling
  ☐ Train Gradient Boosting (should get ~95%)
  ☐ Grid search hyperparameters
  
Week 3:
  ☐ Build ensemble (GB + RF + SVM)
  ☐ Optimize detection threshold
  ☐ Write evaluation report
```

### **Scenario B (1 week)**
```
Days 1-2: Load & explore data
Days 3-4: Train Random Forest, measure speed
Day 5: Optimize for <5ms, compress model
Day 6-7: Deploy to ESP32, final test
```

### **Scenario C (1-2 weeks)**
```
Week 1:
  ☐ Train Isolation Forest on all/normal data
  ☐ Set contamination=0.15
  ☐ Test on historical known attacks
  
Week 2:
  ☐ Tune threshold for desired recall
  ☐ Evaluate on novel attack types
  ☐ Verify zero-shot detection works
```

### **Scenario D (2-4 weeks)**
```
Week 1:
  ☐ Reshape data into sequences (length=10)
  ☐ Build & train LSTM
  ☐ Plot training curves
  
Week 2:
  ☐ Compare LSTM to stateless models
  ☐ Tune sequence length & architecture
  ☐ Add dropout & validation
  
Week 3-4:
  ☐ Combine LSTM + traditional models
  ☐ Deploy TensorFlow model
  ☐ Monitor for concept drift
```

### **Scenario E (4-6 weeks)**
```
Weeks 1-2: Implement all 5 model types
Week 3: Build voting ensemble
Week 4: Add anomaly detection fallback
Week 5: Stress test & failure modes
Week 6: Final real-system test
```

---

## ✅ Success Criteria (For Any Scenario)

```
Must Achieve:
  ☑ Recall > 85%        (catch most real attacks)
  ☑ Precision > 75%     (acceptable false alarms)
  ☑ F1-Score > 80%      (balanced performance)
  ☑ CV Std Dev < 5%     (consistent accuracy)

Should Achieve:
  ☑ Recall > 90%        (very few missed attacks)
  ☑ Precision > 85%     (low false alarm rate)
  ☑ F1-Score > 87%      (strong performance)

Nice to Have:
  ☑ ROC-AUC > 0.95      (excellent discrimination)
  ☑ Inference < 50ms    (acceptable for batch processing)
  ☑ Model size < 5MB    (reasonable for deployment)
```

---

## 🚨 Critical Mistakes (DON'T DO THESE)

```
❌ DON'T: Train and test on all data
   ✅ DO: 80-20 train-test split, never mix

❌ DON'T: Ignore class imbalance (80% normal, 20% sybil)
   ✅ DO: Use class_weight='balanced' or SMOTE

❌ DON'T: Use default threshold 0.5 for imbalanced data
   ✅ DO: Calculate optimal_threshold = cost_FP / (cost_FP + cost_FN)

❌ DON'T: Scale features using all data
   ✅ DO: Fit scaler on training data only, apply to test

❌ DON'T: Report accuracy only (meaningless for imbalanced)
   ✅ DO: Report Precision, Recall, F1, ROC-AUC

❌ DON'T: Use single model for critical systems
   ✅ DO: Use ensemble with fallbacks (Scenario E)
```

---

## 📈 Model Performance Expectations

| Model | Speed | Accuracy | Interpretability | Notes |
|-------|-------|----------|-----------------|-------|
| Logistic Reg | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ | Simple baseline |
| **Random Forest** | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | 🏆 Best for B |
| **Gradient Boost** | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | 🏆 Best for A |
| SVM | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐ | Good for high-dim |
| **Isolation Forest** | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐ | 🏆 Best for C |
| **LSTM** | ⭐⭐ | ⭐⭐⭐⭐ | ⭐ | 🏆 Best for D |
| **Ensemble** | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | 🏆 Best for E |

---

## 🔧 Feature Selection Quickstart

### **Scenario A (High Accuracy) - Use All:**
```python
features = [
    'pps', 'rssi_mean', 'rssi_std',
    'iat_mean', 'iat_std',
    'packet_count', 'packet_size_mean', 'packet_size_std',
    'signal_entropy',  # + signal processing
    'spectral_power',
    # + cross-sensor if available
]
```

### **Scenario B (Edge Fast) - Minimal:**
```python
features = [
    'pps',           # Most important
    'rssi_mean',     # Signal strength
    'iat_mean'       # Timing
]
# Total: 3 features, compute time: <1ms
```

### **Scenario C (Unknown) - Everything:**
```python
features = [
    'pps', 'rssi_mean', 'rssi_std',
    'iat_mean', 'iat_std',
    'signal_entropy', 'spectral_features',
    # DON'T use domain-specific engineered features
]
```

### **Scenario D (Temporal) - Sequences:**
```python
# Instead of aggregated features, use time series:
# Window 1: [pps_1, rssi_1, iat_1, ...]
# Window 2: [pps_2, rssi_2, iat_2, ...]
# ...
# Window 10: [pps_10, rssi_10, iat_10, ...]
# Feed all 10 windows to LSTM at once
```

---

## 📞 Common Questions

**Q: Which scenario should I pick?**
A: Answer the 6 questions at top of this card. Follow logic tree.

**Q: Can I mix scenarios?**
A: Yes! E.g., "Scenario B + occasional retraining = adaptive edge" or "Scenario A + Isolation Forest = Hybrid"

**Q: What if I don't know answers to questions?**
A: Default to Scenario A (highest accuracy) or B (simplest).

**Q: How do I know if my accuracy is good?**
A: Check "Success Criteria" section above. F1 > 80% is minimum.

**Q: Can I skip preprocessing?**
A: Not recommended. Bad preprocessing → bad results (-10-20% accuracy).

**Q: What if my label distribution is 95% normal, 5% Sybil?**
A: Use `class_weight='balanced'` or SMOTE. Essential for this severe imbalance.

---

## 🎯 TL;DR - Start Here If Rushed

```
Pick ONE:
1. High accuracy needed? → Scenario A: Gradient Boosting
2. Very fast needed? → Scenario B: Random Forest
3. No labels? → Scenario C: Isolation Forest
4. Temporal patterns? → Scenario D: LSTM
5. Critical system? → Scenario E: Ensemble

Then:
1. Follow 1-week to 6-week checklist for your scenario
2. Check success criteria frequently
3. Deploy when all checkmarks complete
4. Monitor in production
```

---

## 📚 See Full Docs For:
- Detailed model explanations → `1_MODELS_FOR_SYBIL_DETECTION.md`
- Implementation tutorials → `2_ML_METHODS_AND_APPROACHES.md`
- Complete checklists → `3_CHOOSING_DETECTION_STRATEGY.md`
- Navigation guide → `INDEX.md`

---

**Last Updated**: March 2026  
**Scope**: WBAN Sybil Attack Detection  
**Status**: Production-Ready Guidance
