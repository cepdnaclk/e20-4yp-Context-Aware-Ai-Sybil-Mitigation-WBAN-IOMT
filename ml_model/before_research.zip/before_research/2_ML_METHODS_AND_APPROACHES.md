# ML Methods & Approaches for Sybil Detection

## Overview
This document describes common methodologies and techniques used in machine learning-based Sybil attack detection systems, with focus on what's frequently used in the industry and research.

---

## 1. High-Level Detection Approaches

### 1.1 **Classification-Based Approach** (Most Common)

**Method**: Binary classification (Normal vs Sybil)

**How it works**:
1. Extract features from network traffic (pps, rssi, iat, etc.)
2. Train model on labeled data (known normal + known attacks)
3. Classify new windows as Normal (0) or Sybil (1)
4. Aggregate window predictions to node level

**Pros**:
- Simple to understand and implement
- Works well with labeled training data
- Can achieve 90%+ accuracy

**Cons**:
- Requires labeled attack examples
- Fails on novel attack types not in training data
- Heavily dependent on data quality

**When to use**:
- You have good training data
- Know typical attack patterns
- Need fast inference

**Example in pseudocode**:
```
model = train_classifier(X_train, y_train)
predictions = model.predict(X_test)
sybil_count = count(predictions == 1)
is_node_sybil = sybil_count / total_count > 0.5
```

---

### 1.2 **Anomaly Detection Approach** (Unsupervised)

**Method**: Treat Sybil as "rare anomaly", Normal as "typical"

**How it works**:
1. Train on mostly normal data (or all data)
2. Calculate anomaly score for each sample
3. Flag high-anomaly samples as Sybil
4. No label needed - learns "normal" behavior

**Pros**:
- Works without attack labels
- Detects novel, unseen attacks
- More robust to distribution shifts

**Cons**:
- Often lower accuracy than classification
- Requires setting contamination rate
- Needs more data to learn normal patterns

**When to use**:
- No labeled Sybil data available
- Want to detect unknown attacks
- Data distribution constantly changing

**Algorithms**:
- Isolation Forest
- Local Outlier Factor (LOF)
- One-Class SVM
- Gaussian Mixture Models (GMM)

**Example in pseudocode**:
```
anomaly_detector = train_anomaly(X_train)  # No labels needed
anomaly_scores = anomaly_detector.score(X_test)
is_sybil = anomaly_scores > threshold
```

---

### 1.3 **Hybrid Approach** (Best for Real Systems)

**Method**: Combine classification + anomaly detection

**How it works**:
1. Train classifier on labeled data (high accuracy)
2. Train anomaly detector on normal data (catch unknowns)
3. Final decision = weighted combination

**Pros**:
- Uses both labeled and unlabeled data
- Catches both known and novel attacks
- More robust overall

**Cons**:
- More complex to tune
- Requires more computational resources
- Harder to debug

**When to use**:
- Production systems with new threats appearing
- Mix of known and unknown attacks
- Safety-critical applications (healthcare)

**Example in pseudocode**:
```
classifier_score = classification_model.predict_proba(X)[:, 1]
anomaly_score = anomaly_detector.score(X)

combined_score = 0.6 * classifier_score + 0.4 * anomaly_score
is_sybil = combined_score > threshold
```

---

## 2. Feature Engineering Methods

### 2.1 **Statistical Features** (Most Common)

Extract summary statistics from time-windows of network traffic:

| Feature | Calculation | What It Detects |
|---------|-----------|-----------------|
| **pps** | packets/second | Attack intensity |
| **rssi_mean** | avg signal strength | Device proximity |
| **rssi_std** | variance in signal | Signal consistency |
| **iat_mean** | avg inter-arrival time | Transmission pattern |
| **iat_std** | variance in timing | Timing regularity |
| **packet_count** | total packets in window | Volume |
| **packet_size_mean** | avg packet bytes | Payload size |
| **packet_size_std** | variance in size | Size consistency |

**Example**:
```python
# Extract features from 1-second window
window = traffic_data[start_time:end_time]

features = {
    'pps': len(window) / 1.0,  # packets per second
    'rssi_mean': np.mean(window['rssi']),
    'rssi_std': np.std(window['rssi']),
    'iat_mean': np.mean(np.diff(window['timestamp'])),
}
```

**Pros**: Simple, fast to compute, interpretable
**Cons**: Static, attackers can mimic patterns

---

### 2.2 **Signal Processing Features** (Advanced)

Extract frequency and temporal characteristics:

| Feature | Method | What It Detects |
|---------|--------|-----------------|
| **FFT (Fast Fourier Transform)** | Frequency analysis | Periodic patterns in arrivals |
| **Entropy** | Shannon entropy | Randomness vs pattern |
| **Spectral Power** | Power spectral density | Dominant frequencies |
| **Autocorrelation** | Time series correlation | Periodicity |
| **Wavelet Features** | Wavelet decomposition | Multi-scale patterns |

**Example**:
```python
from scipy.signal import spectrogram
from scipy.stats import entropy

# Entropy of inter-arrival times
iats = np.diff(timestamps)
hist, _ = np.histogram(iats, bins=20)
signal_entropy = entropy(hist)

# Low entropy = predictable (normal)
# High entropy = random (Sybil brute force)
```

**Pros**: Captures signal characteristics, hard to mimic
**Cons**: Computationally expensive, less interpretable

---

### 2.3 **Cross-Sensor Features** (WBAN Specific)

Relationships between multiple sensors on same patient:

| Feature | Calculation | What It Detects |
|---------|-----------|-----------------|
| **ECG-EEG Correlation** | Pearson correlation | Biological synchronization |
| **Heart Rate from Packets** | PPG analysis | Physiological plausibility |
| **Respiration Consistency** | Breathing pattern analysis | Normal vs fabricated |
| **Cross-node Timing** | Timestamp patterns | Fake synchronization |

**Example**:
```python
# ECG and EEG should be somewhat correlated
ecg_signal = sensor_data['ecg_values']
eeg_signal = sensor_data['eeg_values']

correlation = np.corrcoef(ecg_signal, eeg_signal)[0, 1]

# Legitimate nodes: correlation 0.3-0.7
# Sybil nodes: random (correlation ~0)
```

**Pros**: Very hard for attacker to fake, biological grounding
**Cons**: Requires multi-sensor setup, harder to compute

---

## 3. Data Preprocessing Methods

### 3.1 **Standardization (Normalization)**

**Why needed**: Models sensitive to feature scale

**Methods**:

**StandardScaler** (Mean=0, Std=1):
```python
from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_train)

# Feature ranges from -3 to +3 typically
# Good for: Neural Networks, SVM, KNN
```

**MinMaxScaler** (Range 0-1):
```python
from sklearn.preprocessing import MinMaxScaler

scaler = MinMaxScaler(feature_range=(0, 1))
X_scaled = scaler.fit_transform(X_train)

# All features between 0-1
# Good for: Preserving zeros, tree-based models less sensitive
```

**RobustScaler** (Handle outliers):
```python
from sklearn.preprocessing import RobustScaler

scaler = RobustScaler()  # Uses median and IQR
X_scaled = scaler.fit_transform(X_train)

# Better for outlier-heavy data
# Good for: Data with Sybil outliers
```

---

### 3.2 **Handling Missing Values**

**Methods**:

1. **Drop** (Simple but loses data):
   ```python
   X = X.dropna()
   ```

2. **Mean/Median Imputation** (Most common):
   ```python
   X = X.fillna(X.median())  # Robust to outliers
   ```

3. **KNN Imputation** (More sophisticated):
   ```python
   from sklearn.impute import KNNImputer
   imputer = KNNImputer(n_neighbors=5)
   X = imputer.fit_transform(X)
   ```

4. **Iterative Imputation**:
   ```python
   from sklearn.experimental import enable_iterative_imputer
   from sklearn.impute import IterativeImputer
   imputer = IterativeImputer()
   X = imputer.fit_transform(X)
   ```

---

### 3.3 **Class Imbalance Handling**

WBAN networks: 80-95% Normal, 5-20% Sybil

**Methods**:

#### **1. Class Weighting** (Recommended First):
```python
from sklearn.utils.class_weight import compute_class_weight

weights = compute_class_weight('balanced', 
                               classes=[0, 1], 
                               y=y_train)

# Sybil class gets higher penalty for wrong prediction
model.fit(X_train, y_train, class_weight=dict(zip([0,1], weights)))
```

#### **2. SMOTE (Oversampling)** (If weighted insufficient):
```python
from imblearn.over_sampling import SMOTE

smote = SMOTE(k_neighbors=3, random_state=42)
X_resampled, y_resampled = smote.fit_resample(X_train, y_train)

# Creates synthetic Sybil samples by interpolating neighbors
# More balanced dataset: 50-50 split
```

#### **3. Cost-Sensitive Learning**:
```python
# Assign cost to errors
# FN (miss attack) = 10x worse than FP (false alarm)
# Automatically adjusts predictions
```

#### **4. Threshold Adjustment**:
```python
# Instead of threshold=0.5, use:
cost_FN = 10  # Cost of missing attack
cost_FP = 1   # Cost of false alarm
optimal_threshold = cost_FP / (cost_FP + cost_FN)  # ≈ 0.09

y_pred = (y_prob > optimal_threshold).astype(int)
```

---

## 4. Training Strategies

### 4.1 **Train-Test-Validation Split**

**Standard approach**:
```python
# 70% train, 15% validation, 15% test
X_train, X_temp, y_train, y_temp = train_test_split(
    X, y, test_size=0.30, stratify=y, random_state=42
)
X_val, X_test, y_val, y_test = train_test_split(
    X_temp, y_temp, test_size=0.50, stratify=y_temp, random_state=42
)
```

**Why**: 
- Train set: Fit model
- Validation set: Tune hyperparameters, early stopping
- Test set: Final unbiased evaluation

**Critical**: Never train on test set!

---

### 4.2 **Cross-Validation**

Reuse data for more robust evaluation:

```python
from sklearn.model_selection import StratifiedKFold

kfold = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

scores = []
for train_idx, test_idx in kfold.split(X, y):
    X_train, X_test = X[train_idx], X[test_idx]
    y_train, y_test = y[train_idx], y[test_idx]
    
    model.fit(X_train, y_train)
    scores.append(model.score(X_test, y_test))

print(f"Average Score: {np.mean(scores):.2%}")
print(f"Standard Deviation: {np.std(scores):.2%}")
```

**Benefits**:
- Better estimate of true performance
- Use all data for training
- Lower variance in evaluation

---

### 4.3 **Hyperparameter Tuning**

Find best model configuration:

#### **Grid Search** (Exhaustive):
```python
from sklearn.model_selection import GridSearchCV

params = {
    'n_estimators': [100, 200, 300],
    'max_depth': [5, 10, 15],
    'min_samples_leaf': [1, 5, 10]
}

grid = GridSearchCV(
    RandomForestClassifier(),
    params,
    cv=5,
    scoring='f1'
)

grid.fit(X_train, y_train)
print(f"Best params: {grid.best_params_}")
print(f"Best score: {grid.best_score_:.2%}")
```

#### **Random Search** (Faster):
```python
from sklearn.model_selection import RandomizedSearchCV

random_search = RandomizedSearchCV(
    RandomForestClassifier(),
    params,
    n_iter=20,  # Try 20 random combinations
    cv=5,
    random_state=42
)

random_search.fit(X_train, y_train)
```

#### **Bayesian Optimization** (Most efficient):
```python
from skopt import BayesSearchCV

bayes = BayesSearchCV(
    RandomForestClassifier(),
    params,
    n_iter=30,
    cv=5,
    random_state=42
)

bayes.fit(X_train, y_train)
```

---

## 5. Evaluation Metrics

### 5.1 **Classification Metrics**

```python
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, 
    f1_score, roc_auc_score, confusion_matrix
)

# For Sybil detection, RECALL > PRECISION
# (Missing attack worse than false alarm)

y_pred = model.predict(X_test)

accuracy = accuracy_score(y_test, y_pred)    # Overall correctness
precision = precision_score(y_test, y_pred)  # Of predicted Sybils, how many correct
recall = recall_score(y_test, y_pred)        # Of actual Sybils, how many detected
f1 = f1_score(y_test, y_pred)                # Harmonic mean (balanced metric)
```

### 5.2 **Threshold-Independent Metrics**

```python
from sklearn.metrics import roc_auc_score, auc, roc_curve

y_prob = model.predict_proba(X_test)[:, 1]

# ROC-AUC: Performance across all thresholds
roc_auc = roc_auc_score(y_test, y_prob)

# Precision-Recall AUC: Better for imbalanced
from sklearn.metrics import average_precision_score
pr_auc = average_precision_score(y_test, y_prob)
```

---

## 6. Frequently Used Industry Methods

### 6.1 **Approaches Used in WBAN Security Research**

| Approach | Popularity | Accuracy | Reason |
|----------|-----------|----------|--------|
| Random Forest | ⭐⭐⭐⭐⭐ | 90-94% | Simple, effective, interpretable |
| Gradient Boosting | ⭐⭐⭐⭐⭐ | 92-96% | Best accuracy, handles imbalance |
| SVM | ⭐⭐⭐⭐ | 88-92% | Good for high-dim data |
| Neural Networks | ⭐⭐⭐⭐ | 90-94% | Flexible, learns representations |
| Isolation Forest | ⭐⭐⭐ | 85-90% | Anomaly-focused, novel attacks |
| Clustering (K-means) | ⭐⭐⭐ | 80-85% | Unsupervised baseline |
| Statistical Tests | ⭐⭐ | 75-85% | Simple threshold rules |

### 6.2 **Standard Preprocessing Pipeline**

Most researchers follow this standard:

```python
from sklearn.pipeline import Pipeline

pipeline = Pipeline([
    ('scaler', StandardScaler()),
    ('classifier', RandomForestClassifier(
        n_estimators=300,
        class_weight='balanced',
        random_state=42
    ))
])

pipeline.fit(X_train, y_train)
```

### 6.3 **Standard Evaluation Protocol**

Standard in research publications:

```python
# 1. Stratified train-test split (80-20)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42
)

# 2. 5-Fold Cross-Validation for robustness
# 3. Report: Accuracy, Precision, Recall, F1
# 4. Plot: ROC curve, Confusion matrix
# 5. Statistical test if comparing methods (t-test, etc.)
```

---

## 7. Timeline Overview: What to Implement When

```
Phase 1 (Week 1): Basic Classification
└─ Extract statistical features (pps, rssi, iat)
└─ Train Random Forest baseline
└─ Evaluate on test set
└─ Expected: 85-90% accuracy

Phase 2 (Week 2): Advanced Preprocessing
└─ Add class weighting for imbalance
└─ Implement SMOTE oversampling
└─ Try threshold optimization
└─ Expected: 90-94% accuracy

Phase 3 (Week 3): Multiple Models
└─ Compare RF vs Gradient Boosting vs SVM
└─ Implement hyperparameter tuning
└─ Build ensemble of best models
└─ Expected: 93-95% accuracy

Phase 4 (Week 4): Advanced Features
└─ Add signal processing features (entropy, FFT)
└─ Evaluate anomaly detection (Isolation Forest)
└─ Consider temporal modeling (LSTM)
└─ Expected: 94-96% accuracy

Phase 5 (Production): Real-World Validation
└─ Test on real WBAN data
└─ Implement online learning updates
└─ Add interpretability/explainability
└─ Deploy with monitoring
```

---

## Next Steps

1. See `1_MODELS_FOR_SYBIL_DETECTION.md` for model details
2. See `3_CHOOSING_DETECTION_STRATEGY.md` for selection framework
3. Implement Phase 1 baseline (Random Forest)
4. Evaluate and iterate

