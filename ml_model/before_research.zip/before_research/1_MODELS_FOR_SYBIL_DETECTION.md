# Models for Sybil Attack Detection: Selection & Justification

## Overview
This document details which machine learning models are suitable for detecting Sybil attacks in Wireless Body Area Networks (WBANs) and the reasons for choosing them.

---

## 1. Quick Reference: Model Comparison

| Model | Type | Best For | Speed | Accuracy | Interpretable | Reason for Choice |
|-------|------|----------|-------|----------|---------------|-------------------|
| **Logistic Regression** | Linear | Baseline | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ | Interpretable baseline |
| **Random Forest** | Ensemble | Non-linear relationships | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | Strong general performer |
| **Gradient Boosting** | Ensemble | Complex patterns | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | Best accuracy for imbalanced |
| **Support Vector Machine** | Kernel-based | High dims | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐ | Good for outlier detection |
| **Neural Networks (MLP)** | Deep Learning | Learned representations | ⭐⭐ | ⭐⭐⭐⭐ | ⭐ | Flexible, handles complexity |
| **XGBoost** | Ensemble | Fast & accurate | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐ | Fast gradient boosting |
| **Isolation Forest** | Anomaly Detection | Rare anomalies | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐ | Designed for outliers |
| **Local Outlier Factor** | Anomaly Detection | Local anomalies | ⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐ | Per-sample baselines |
| **LSTM/RNN** | Temporal | Sequence patterns | ⭐ | ⭐⭐⭐⭐⭐ | ⭐ | Captures temporal deps |

---

## 2. Recommended Models for WBAN Sybil Detection

### 2.1 **Random Forest** ⭐⭐⭐⭐⭐ (Top Choice)

**What it does:**
- Builds 100-300 decision trees on random data subsets
- Each tree learns different patterns
- Final prediction = majority vote across all trees

**Why it's good for Sybil detection:**

1. **Handles Non-linear Relationships**
   - Sybil attacks show complex patterns
   - Not just linear behavior like: `if pps > 100 then Sybil`
   - RF captures interactions: `if (pps > 50 AND rssi_std < 5) then Sybil`

2. **Feature Importance Built-in**
   - Shows which features matter most
   - Tells you: "rssi_mean is 3x more important than packet_size"
   - Guides feature engineering

3. **Handles Imbalanced Data**
   - WBANs have 80-95% normal, 5-20% Sybil data
   - RF with `class_weight="balanced"` penalizes Sybil misclassification
   - Better than Logistic Regression which leans toward majority class

4. **Robust to Outliers**
   - Sybil nodes may have extreme values
   - RF trees ignore outliers naturally
   - Won't crash with missing values

5. **Fast Inference**
   - ~1-5ms per prediction
   - Can run on edge devices (ESP32)
   - Real-time detection possible

**Code Example:**
```python
from sklearn.ensemble import RandomForestClassifier

rf = RandomForestClassifier(
    n_estimators=300,          # 300 trees
    class_weight="balanced",    # Handle imbalance
    random_state=42,
    max_depth=15,              # Prevent overfitting
    min_samples_leaf=5
)

rf.fit(X_train, y_train)

# Get feature importance
importances = pd.Series(
    rf.feature_importances_,
    index=X_train.columns
).sort_values(ascending=False)

print(importances.head(10))
```

---

### 2.2 **Gradient Boosting** ⭐⭐⭐⭐⭐ (Highest Accuracy)

**What it does:**
- Builds trees **sequentially**
- Each new tree corrects errors of previous trees
- Focuses learning on hard-to-classify samples

**Why it's good for Sybil detection:**

1. **Best Accuracy**
   - Iterative error correction
   - Often 5-10% better F1-score than Random Forest
   - Worth slightly slower inference

2. **Emphasizes Hard Cases**
   - Early trees catch obvious Sybils
   - Later trees focus on subtle attacks
   - Sophisticated attackers with weak signals still caught

3. **Natural Imbalance Handling**
   - Can use `sample_weight` to emphasize minority class
   - Boosts weighted training on Sybil samples

4. **Overfitting Protection**
   - Learning rate parameter prevents memorization
   - Can validate on hold-out set during training

**Code Example:**
```python
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.utils.class_weight import compute_sample_weight

# Compute weights for imbalanced data
sample_weights = compute_sample_weight('balanced', y_train)

gb = GradientBoostingClassifier(
    n_estimators=200,
    learning_rate=0.1,         # Lower = slower but better generalization
    max_depth=5,               # Shallow trees, prevent overfitting
    random_state=42
)

gb.fit(X_train, y_train, sample_weight=sample_weights)

# Predictions with probabilities
y_prob = gb.predict_proba(X_test)[:, 1]
```

---

### 2.3 **Support Vector Machine (SVM)** ⭐⭐⭐⭐ (Specialized)

**What it does:**
- Finds line/surface that separates Normal from Sybil
- Uses "kernel trick" for complex non-linear boundaries
- Maximizes margin between classes

**Why it's good for Sybil detection:**

1. **Excellent for High Dimensions**
   - WBAN data may have 20-50 features
   - SVM specifically designed for high-d problems
   - Random Forest struggles with 100+ features

2. **Customizable Kernels**
   - Linear kernel: Simple attacks
   - RBF kernel: Complex signal patterns
   - Polynomial kernel: Feature interactions

3. **Handles Class Imbalance**
   - Use `class_weight="balanced"`
   - Or manually set `C` parameter per class
   - Can adjust decision boundary

**When to use:**
- Feature count > 50
- Clear separation unlikely
- Need to tune decision boundary

**Code Example:**
```python
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler

# SVM requires scaling
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

svm = SVC(
    kernel='rbf',              # RBF for non-linear
    C=1.0,                     # Regularization strength
    class_weight='balanced',
    probability=True           # Get probabilities for ROC curve
)

svm.fit(X_train_scaled, y_train)
```

---

### 2.4 **Isolation Forest** ⭐⭐⭐⭐ (Anomaly Detection)

**What it does:**
- Treats Sybil as "anomaly" not "classification"
- Builds random trees to "isolate" outliers
- Fewer splits needed to isolate rare points

**Why it's good for Sybil detection:**

1. **Designed for Rare Events**
   - Sybil is rare (5-20% of traffic)
   - Other methods optimized for 50-50 split
   - Isolation Forest native to imbalanced

2. **No Labels Needed (Semi-supervised)**
   - Can detect novel attack types
   - Doesn't memorize training data
   - Better generalization to unknown attacks

3. **Fast Training**
   - O(n log n) complexity
   - Good for large datasets
   - Can handle unbounded features

**Key Insight:**
- Normal nodes: Many splits to isolate
- Sybil nodes: Few splits (obvious anomalies)

**Code Example:**
```python
from sklearn.ensemble import IsolationForest

iso_forest = IsolationForest(
    contamination=0.15,        # Expected % of Sybil (5-20% typical)
    random_state=42,
    n_estimators=100
)

# Fit on unlabeled or all data
y_pred = iso_forest.fit_predict(X)  # Returns -1 (Sybil), 1 (Normal)
y_prob = -iso_forest.score_samples(X)  # Anomaly score

# Threshold for classification
sybil_score = -iso_forest.score_samples(X_test)
is_sybil = sybil_score > np.percentile(sybil_score, 85)
```

---

### 2.5 **LSTM (Long Short-Term Memory)** ⭐⭐⭐⭐ (Temporal Patterns)

**What it does:**
- Neural network that remembers sequences
- Each window predicted based on last N windows
- Learns temporal dependencies

**Why it's good for Sybil detection:**

1. **Captures Temporal Patterns**
   - Legitimate sensors: Smooth, predictable patterns
   - Sybil nodes: Random or unexpected changes
   - LSTM learns "normal" sequence behavior

2. **Sequential Information**
   - Example: If heart rate suddenly jumps from 60→200, anomalous?
   - LSTM checks: Was previous trend gradual? (normal) or sudden jump? (Sybil)
   - Better than individual window analysis

3. **Learns Feature Interactions Over Time**
   - `rssi` drops AND `pps` rises = Sybil signal?
   - LSTM learns if these co-occur that's abnormal
   - Captures complex timing

**Example Scenario:**
```
Window 1: pps=50, rssi_mean=80
Window 2: pps=52, rssi_mean=79  (normal change)
Window 3: pps=51, rssi_mean=81  (smooth variation)

vs.

Window 1: pps=20, rssi_mean=90
Window 2: pps=200, rssi_mean=20  (sudden jump - anamalous!)
Window 3: pps=150, rssi_mean=35
```

LSTM detects the sudden changes better than static models.

**Code Example:**
```python
from tensorflow.keras import layers, models

# Reshape into sequences
def create_sequences(X, y, seq_len=10):
    X_seq, y_seq = [], []
    for i in range(len(X) - seq_len):
        X_seq.append(X[i:i+seq_len])
        y_seq.append(y[i+seq_len])
    return np.array(X_seq), np.array(y_seq)

X_seq, y_seq = create_sequences(X_train, y_train, seq_len=10)

lstm_model = models.Sequential([
    layers.LSTM(64, activation='relu', input_shape=(10, X_train.shape[1])),
    layers.Dropout(0.2),
    layers.Dense(32, activation='relu'),
    layers.Dense(1, activation='sigmoid')
])

lstm_model.compile(
    optimizer='adam',
    loss='binary_crossentropy',
    metrics=['accuracy']
)

lstm_model.fit(X_seq, y_seq, epochs=50, batch_size=32)
```

---

### 2.6 **Logistic Regression** ⭐⭐⭐⭐⭐ (Fast Baseline)

**What it does:**
- Linear classification model
- Outputs probability of sample being Sybil (0-1)
- Uses gradient descent to minimize classification error

**Why it's good for Sybil detection:**

1. **Extremely Fast**
   - Simplest model: Linear decision boundary
   - 0.1-1ms per prediction
   - Perfect for edge devices with tight time constraints

2. **Interpretable Results**
   - Shows coefficient weight for each feature
   - Tells you: "rssi_mean has 5× more impact than pps"
   - Great for justifying decisions in healthcare papers

3. **Handles Imbalanced Data**
   - Use `class_weight="balanced"` parameter
   - Custom penalties for false positives/negatives
   - Can adjust decision threshold (not just 0.5)

4. **Probabilistic Output**
   - Returns probability of being Sybil
   - Confidence measure for decisions
   - Can set custom threshold: if P(Sybil) > 0.3 then flag

5. **Fast Training**
   - Linear complexity: O(n × features)
   - Trains in milliseconds even on large datasets
   - Can retrain frequently as new data arrives

6. **Good Baseline**
   - Establish minimum performance threshold
   - Compare other models against it
   - If complex model ≈ logistic regression, not worth added complexity

**Limitations:**
- Linear decision boundary only (simple attacks only)
- Can't capture feature interactions
- May undershoot in complex WBAN scenarios

**Code Example:**
```python
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler

# Logistic Regression benefits from scaling
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

lr = LogisticRegression(
    class_weight='balanced',        # Handle imbalance
    max_iter=1000,                 # Convergence iterations
    random_state=42,
    solver='liblinear'              # Good for small datasets
)

lr.fit(X_train_scaled, y_train)

# Get feature coefficients
feature_importance = pd.Series(
    lr.coef_[0],
    index=X_train.columns
).sort_values(key=abs, ascending=False)

print(f"Feature weights:\n{feature_importance}")

# Predictions with tunable threshold
y_prob = lr.predict_proba(X_test_scaled)[:, 1]
threshold = 0.3  # Custom threshold (not 0.5)
y_pred = (y_prob > threshold).astype(int)
```

**When to use Logistic Regression:**
- ✓ Real-time edge device deployment (ESP32)
- ✓ Need interpretable results for paper
- ✓ Need very fast inference (<1ms)
- ✓ Quick baseline to compare against
- ✗ Complex attack patterns (use Random Forest/GB instead)

---

### 2.7 **Multi-Layer Perceptron (MLP)** ⭐⭐⭐⭐ (Neural Network)

**What it does:**
- Artificial neural network with hidden layers
- Learns non-linear patterns through multiple transformations
- Each layer learns increasingly abstract features

**Why it's good for Sybil detection:**

1. **Learns Complex Non-linear Patterns**
   - Multiple hidden layers capture feature interactions
   - Example: Detects "if (pps drops AND rssi_std increases) then Sybil"
   - Better than Logistic Regression on complex attacks

2. **Automatic Feature Engineering**
   - Hidden layers automatically combine raw features
   - Don't need to manually engineer interactions
   - Learns optimal representations for classification

3. **Handles Imbalanced Data**
   - Use `class_weight="balanced"` parameter
   - Custom sample weighting
   - Careful hyperparameter selection

4. **Flexible Architecture**
   - Adjust number of hidden layers (deeper = more complex)
   - Adjust neurons per layer
   - Can be as simple or complex as dataset requires

5. **Good Accuracy**
   - 93% F1-score typical with proper tuning
   - Competitive with Gradient Boosting
   - Less prone to overfitting than single decision trees

**Limitations:**
- Slower inference: 10-50ms per prediction (not for ESP32)
- "Black box" - hard to explain why decision made
- Requires more data than tree-based methods
- Need careful hyperparameter tuning (learning rate, architecture)

**Code Example:**
```python
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler

# Neural networks REQUIRE feature scaling
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

mlp = MLPClassifier(
    hidden_layer_sizes=(128, 64, 32),  # 3 hidden layers
    activation='relu',                  # ReLU activation
    solver='adam',                      # Adam optimizer
    learning_rate='adaptive',           # Adaptive learning rate
    max_iter=1000,
    random_state=42,
    early_stopping=True,                # Stop if validation doesn't improve
    validation_fraction=0.1             # Use 10% for validation
)

mlp.fit(X_train_scaled, y_train)

# Evaluate
y_pred = mlp.predict(X_test_scaled)
y_prob = mlp.predict_proba(X_test_scaled)[:, 1]

print(f"Training accuracy: {mlp.score(X_train_scaled, y_train):.4f}")
print(f"Test accuracy: {mlp.score(X_test_scaled, y_test):.4f}")
```

**Architecture Tips:**
- **Shallow (1 layer)**: Fast but may underfit complex patterns 
- **Medium (2-3 layers)**: Balance of speed and accuracy (recommended)
- **Deep (4+ layers)**: Risk of overfitting, needs more data
- **Layer sizes**: Gradually decrease (128→64→32) or constant

**When to use MLP:**
- ✓ Need better accuracy than Logistic Regression
- ✓ Server-side deployment (not edge devices)
- ✓ Have enough training data (500+ samples)
- ✓ Don't need explainability
- ✗ ESP32 real-time (too slow)
- ✗ Need interpretable model (black box)

---

### 2.8 **XGBoost** ⭐⭐⭐⭐⭐ (Fast Gradient Boosting)

**What it does:**
- Optimized gradient boosting algorithm
- Sequentially builds trees, each correcting errors of previous
- Uses advanced regularization to prevent overfitting
- Faster than standard Gradient Boosting

**Why it's good for Sybil detection:**

1. **Best-in-Class Accuracy**
   - Often 1-2% better than Gradient Boosting
   - 96%+ F1-score typical
   - State-of-the-art for imbalanced data

2. **Faster Than Gradient Boosting**
   - 20-50% faster training time
   - 10-50ms inference still slower than Random Forest
   - Better speed/accuracy tradeoff

3. **Robust Regularization**
   - L1 and L2 penalties prevent overfitting
   - Good generalization to new attacks
   - Works well even with limited labeled data

4. **Handles Imbalanced Data Natively**
   - `scale_pos_weight` parameter for class imbalance
   - Automatically weights minority class
   - Doesn't need manual sample weighting

5. **Feature Importance & Interactions**
   - Shows both single feature importance
   - Shows feature interactions automatically discovered
   - Explainable for research papers

6. **GPU Acceleration Available**
   - Can use GPU for training (faster on large datasets)
   - Tree learning parallelized
   - Useful if processing many models

**Limitations:**
- Not as fast as Random Forest: 10-50ms inference
- Can't run effectively on ESP32 (too slow)
- More complex hyperparameters than Random Forest
- Requires separate installation (`pip install xgboost`)

**Code Example:**
```python
import xgboost as xgb
from sklearn.utils.class_weight import compute_sample_weight

# Calculate scale for imbalanced data
scale_pos_weight = sum(y_train == 0) / sum(y_train == 1)

xgb_model = xgb.XGBClassifier(
    n_estimators=200,               # Number of boosting trees
    learning_rate=0.1,              # How fast it learns
    max_depth=5,                    # Shallow trees prevent overfitting
    scale_pos_weight=scale_pos_weight,  # Weight for imbalance
    random_state=42,
    tree_method='hist',             # Fast histogram-based training
    objective='binary:logistic',     # Binary classification
    eval_metric='logloss'
)

xgb_model.fit(
    X_train, y_train,
    eval_set=[(X_test, y_test)],    # Monitor test performance
    early_stopping_rounds=10,       # Stop if test doesn't improve
    verbose=False
)

# Feature importance
feature_importance = pd.DataFrame({
    'feature': X_train.columns,
    'importance': xgb_model.feature_importances_
}).sort_values('importance', ascending=False)

print(f"Top features:\n{feature_importance.head(10)}")

# Predictions
y_pred = xgb_model.predict(X_test)
y_prob = xgb_model.predict_proba(X_test)[:, 1]
```

**Hyperparameter Tuning for WBAN:**
```python
from sklearn.model_selection import GridSearchCV

param_grid = {
    'max_depth': [3, 5, 7],
    'learning_rate': [0.01, 0.1, 0.3],
    'n_estimators': [100, 200, 300],
    'subsample': [0.8, 1.0],  # Row sampling
}

grid_search = GridSearchCV(
    xgb.XGBClassifier(scale_pos_weight=scale_pos_weight),
    param_grid,
    cv=5,
    scoring='f1',
    n_jobs=-1  # Use all CPU cores
)

grid_search.fit(X_train, y_train)
print(f"Best params: {grid_search.best_params_}")
print(f"Best F1-score: {grid_search.best_score_:.4f}")
```

**When to use XGBoost:**
- ✓ Need highest accuracy (96%+ F1)
- ✓ Server-side deployment (not edge)
- ✓ Can accept 10-50ms inference latency
- ✓ Need state-of-the-art results for publication
- ✓ Have time for hyperparameter tuning
- ✗ Real-time ESP32 deployment (too slow)
- ✗ Very limited CPU/memory (use Random Forest instead)

**XGBoost vs Gradient Boosting vs Random Forest:**
| Aspect | RF | GB | XGBoost |
| - | - | - | - |
| Speed | 1-5ms | 50-100ms | 10-50ms |
| Accuracy | 92% | 95% | 96% |
| Interpretable | High | Medium | Medium |
| Training time | Fast | Slow | Medium |
| Overfitting | Medium | High risk | Low risk |
| For publication | Good | Great | Best |

---

## 3. Why NOT to Use Certain Models

### ❌ **Naive Bayes**
- **Problem**: Assumes features are independent
- **Reality**: pps, rssi, iat are correlated
- **Result**: Poor accuracy on WBAN data

### ❌ **Decision Trees (Single)**
- **Problem**: Overfits easily, memorizes data
- **Reality**: Training vs test accuracy differs 20%+
- **Result**: Fails on real attacks

### ❌ **KNN (K-Nearest Neighbors)**
- **Problem**: Slow inference O(n) per sample
- **Reality**: Need to compare to all training samples
- **Result**: Not viable for real-time (>100ms latency)

### ❌ **Simple Threshold Rules** (if pps > 100 then Sybil)
- **Problem**: Attackers adapt to known thresholds
- **Reality**: Brute force attacks adjust rate to avoid detection
- **Result**: False negatives when adversary evolves

---

## 4. Model Selection Decision Tree

### 4.1 Generic Decision Tree

```
START

├─ Is temporal information important?
│  ├─ YES → Use LSTM or Temporal Ensemble
│  └─ NO → Continue
│
├─ Is inference speed critical? ⏱️ (time to make predictions)
│  ├─ YES (need <5ms per prediction)
│  │  ├─ Random Forest
│  │  └─ Logistic Regression
│  └─ NO (up to 50-100ms acceptable)
│     └─ Continue
│
├─ Do you have labeled Sybil data?
│  ├─ YES (supervised learning)
│  │  ├─ Use Gradient Boosting (best accuracy)
│  │  └─ Use Random Forest (most robust)
│  └─ NO (unsupervised)
│     └─ Use Isolation Forest
│
└─ END → Select model
```

---

### **What Does "Inference Speed Critical" Mean?**

**Inference speed** = How fast the model makes predictions

**Critical** = Time is a limiting factor in application

**Explanation:**

| Term | Meaning | Example |
|------|---------|---------|
| **Inference** | When model makes prediction on new data | Model sees new sensor readings, predicts if Sybil or Normal |
| **Speed** | Time taken to make that prediction | Does prediction take 1ms? 50ms? 10 seconds? |
| **Critical** | Must be fast enough for use case | If YES, must choose fast models; If NO, speed doesn't matter |

---

### **When is Inference Speed CRITICAL (YES)?**

**use case REQUIRES speed:**

1. **Real-time monitoring on edge devices (ESP32, wearable)**
   - Model running on microcontroller
   - Must predict <5-10ms between sensor readings
   - Can't wait for slow computation
   - Example: ESP32 WBAN sensor node checking itself in real-time
   
2. **Streaming live data processing**
   - Predictions needed as data arrives
   - Can't batch (wait for 100 samples)
   - Latency is critical
   - Example: Hospital monitoring 10 patients simultaneously
   
3. **Automatic alerts needed immediately**
   - Attack detected = alert within milliseconds
   - Doctor must be notified instantly
   - Delay = potential harm
   - Example: ICU warning of compromised vital signs

**Models to use if CRITICAL:**
- Random Forest (1-5ms) ✅
- Logistic Regression (0.1-1ms) ✅
- Decision Trees (0.1-1ms) ✅
- SVM (5-20ms) ⚠️
- Gradient Boosting (10-50ms) ❌

---

### **When is Inference Speed NOT CRITICAL (YES)?**

**use case allows waiting:**

1. **Research/Offline Analysis**
   - Processing historical data
   - Batch predictions (1000+ samples at once)
   - Can wait minutes to hours
   - Example: Analyzing last month of WBAN data
   - Time taken: 1 minute = Fine
   
2. **Periodic scanning (minutes/hours apart)**
   - Check system once per hour
   - Not continuous monitoring
   - Can afford 30-60 second computation
   - Example: Nightly security audit of WBAN
   
3. **High-accuracy requirement justifies slower speed**
   - Better accuracy (95% vs 92%) matters for healthcare
   - Can wait extra seconds for correct diagnosis
   - Example: Critical patient decision
   - Time taken: 5 seconds = Acceptable

**Models to use if NOT CRITICAL:**
- Gradient Boosting (95%+ accuracy) ✅
- LSTM/Neural Networks (best accuracy) ✅
- Ensemble methods (96%+ accuracy) ✅
- Complex hyperparameter tuning (slow to train but good results) ✅

---

### **Inference Speed Examples by Scenario**

```
SCENARIO A: Hospital WBAN Monitoring
├─ Requirements:
│  ├─ Check for attacks: Every 1 second
│  ├─ Predictions needed: Within 100ms (human reaction time)
│  └─ Speed critical?: NO (100ms is slow enough)
├─ Why NOT critical?
│  └─ 100ms << 1000ms (1 second between checks)
└─ Models OK: Gradient Boosting, Ensemble (both <100ms)

SCENARIO B: ESP32 Wearable Running Detection Locally
├─ Requirements:
│  ├─ New sensor data: Every 20ms
│  ├─ Prediction must be done: Before next sample arrives
│  └─ Speed critical?: YES (need <15ms inference)
├─ Why critical?
│  └─ 15ms << 20ms (must finish before next data)
└─ Models ONLY: Random Forest (<5ms), Logistic Regression (<1ms)

SCENARIO C: Research Paper - Batch Analysis
├─ Requirements:
│  ├─ Analyze 10,000 historical samples
│  ├─ Analysis can take: 1-10 minutes
│  └─ Speed critical?: NO (batching, not real-time)
├─ Why NOT critical?
│  └─ Total: 1 minute for all = Fine
│  └─ Average: 0.1ms per sample = Who cares?
└─ Models OK: Anything (accuracy matters, speed doesn't)

SCENARIO D: IoT Attack Detection Network
├─ Requirements:
│  ├─ 1000 sensor nodes transmitting
│  ├─ Process all: Every 1 minute
│  ├─ Prediction per node: 1000 predictions total
│  └─ Speed critical?: NO (batch processing acceptable)
├─ Why NOT critical?
│  └─ 60 seconds available / 1000 predictions = 60ms per prediction
│  └─ Gradient Boosting (50ms) = Just fits!
└─ Models OK: Gradient Boosting, Ensemble
```

---

### **How to Answer for Research**

**Your context:**
- Real-time deployment to ESP32 edge devices
- Need predictions within 5-10ms per sensor reading
- Accuracy important but not at cost of speed
- Creating labeled dataset for validation

**ANSWER: YES (inference speed IS critical)**

**Why?**
- Running detection on microcontroller in real-time
- Must complete prediction before next sensor sample arrives
- ESP32 has limited CPU/memory resources
- Latency directly impacts attack detection response time

**Implication:**
- Use FAST models even if accuracy is slightly lower
- Random Forest (1-5ms, 92% F1) ✅ PRIMARY
- Logistic Regression (0.1-1ms, 80% F1) ✅ BASELINE
- NOT Gradient Boosting (50-100ms, too slow) ❌
- NOT Ensemble/LSTM (100-500ms, way too slow) ❌

---

### **Speed Comparison Table**

When inference speed IS critical, use fast models:

| Model | Speed | Accuracy | When to use |
|-------|-------|----------|------------|
| Logistic Regression | 0.1-1ms ⭐⭐⭐⭐⭐ | 80% | Edge device, very fast needed |
| Random Forest | 1-5ms ⭐⭐⭐⭐⭐ | 92% | Edge device, good accuracy |
| Decision Tree | 0.1-1ms ⭐⭐⭐⭐⭐ | 75% | Edge device, sacrifices accuracy |
| SVM | 5-20ms ⭐⭐⭐⭐ | 91% | Medium speed requirement |
| **Gradient Boosting** | **50-100ms** ⭐⭐⭐ | **95%** | **Research, NOT edge** |
| Neural Network | 10-50ms ⭐⭐⭐ | 93% | Some real-time OK |
| LSTM | 50-200ms ⭐⭐ | 94% | Research, slow OK |
| Ensemble | 100-500ms ⭐⭐ | 96% | Research, accuracy priority |

---

### 4.2 Research: Decision Tree

**Research Context:**
- Goal: Identify Sybil attacks in WBAN
- Data: Custom dataset with labeled Sybil + Normal sensor data
- Task: Predict which sensor nodes are Sybil

**Decision Tree:**

```
START: WBAN Sybil Attack Detection Research

├─ Is temporal information important?
│  │
│  ├─ ANSWER: OPTIONAL (depends on data format)
│  │  ├─ If using raw time-series data → YES → Use LSTM
│  │  └─ If using statistical features (pps, rssi) → NO → Continue
│  │
│  └─ CHOICE: Start with NO (because of use statistical features)
│     "Dataset with extracted sensor features, not raw time-series"
│
├─ Is inference speed critical? (<5ms required)
│  │
│  ├─ ANSWER: YES ✓
│  │  "Need real-time detection on edge devices (ESP32)"
│  │  "Predictions must complete within 5-10ms"
│  │
│  └─ ACTION: Must use fast models for real-time inference
│
├─ Do you have labeled Sybil data?
│  │
│  ├─ ANSWER: YES ✓ STRONG YES
│  │  "Creating dataset ourself with ground truth labels"
│  │  "Full control over what's Sybil and what's Normal"
│  │  "Can generate multiple attack scenarios"
│  │
│  └─ ACTION: Supervised learning approach optimal
│
└─ END → RECOMMENDATIONS FOR RESEARCH

BEST OPTIONS (in order):

1. PRIMARY: Random Forest ⭐⭐⭐⭐⭐
   ✓ Fast inference: 1-5ms per prediction
   ✓ Good accuracy: 92% F1-score
   ✓ Can run on ESP32 edge devices
   ✓ Perfect for real-time WBAN monitoring
   
2. SECONDARY: Logistic Regression ⭐⭐⭐⭐
   ✓ Extremely fast: 0.1-1ms per prediction
   ✓ Low memory footprint for microcontrollers
   ✓ Baseline accuracy: 80% F1-score
   ✓ Good for comparing against RF
   
3. OPTIONAL: Gradient Boosting (offline analysis only)
   ✗ Too slow: 50-100ms per prediction
   ⚠️ Cannot deploy to ESP32 in real-time
   ✓ Can use for offline research/analysis phase
   ✓ Cannot use for field deployment

4. NOT RECOMMENDED: LSTM/Ensemble
   ✗ Too slow (50-500ms) for edge devices
   ❌ Not suitable for real-time requirements
```

---

## 4.3 Detailed Recommendations for WBAN Research (Speed-Critical Deployment)

### **Why Random Forest First?**

For research deploying to edge devices (ESP32) with real-time requirements:

**Perfect Fit Because:**
1. ✓ Fast inference: 1-5ms per prediction (meets <5ms requirement)
2. ✓ Can run on microcontrollers (low memory)
3. ✓ Good accuracy: 92% F1-score (acceptable for healthcare)
4. ✓ Feature importance built-in (understand detection)
5. ✓ Can serve as baseline for real-time system

**Expected Results:**
- Speed: 1-5ms per prediction ✓
- Accuracy: 90-93%
- Precision: 80-85%
- Recall: 85-90%
- F1-Score: 87-91%

---

### **Why Also Test Logistic Regression?**

Complement RF with baseline for edge deployment:

**Why Both?**
1. Shows speed-accuracy tradeoff
2. Logistic Regression: 0.1-1ms (ultrafast) but 80% F1
3. Random Forest: 1-5ms (fast) and 92% F1
4. Helps decide which fits ESP32 constraints
5. Demonstrates optimization for resource-constrained devices

**Typical Deployment Strategy:**
```
"We compared two fast models suitable for edge deployment:
  - Baseline: Logistic Regression (0.1-1ms, 80% F1)
  - Proposed: Random Forest (1-5ms, 92% F1)
  - Both: Deployable to ESP32 microcontroller
  - Gradient Boosting: Analyzed offline only (too slow for real-time)"
```

---

### **Step-by-Step for Speed-Critical Research**

```
PHASE 1: Dataset Creation (Week 1)
  ☐ Create normal sensor data (legitimate nodes at ESP32 sampling rate)
  ☐ Create Sybil attack data (attack scenarios 1-5)
  ☐ Label everything (0=Normal, 1=Sybil)
  ☐ Extract features (pps, rssi, iat, etc.)
  ☐ Dataset size: Aim for 1000+ samples

PHASE 2: Fast Model Testing (Week 2-3)
  ☐ Train Logistic Regression (baseline for ESP32)
  ☐ Train Random Forest (primary model)
  ☐ Benchmark inference speed on ESP32 hardware
  ☐ Calculate: Accuracy, Precision, Recall, F1
  ☐ Time each prediction (<5ms requirement)

PHASE 3: Optimization (Week 3-4)
  ☐ Hyperparameter tuning for speed/accuracy tradeoff
  ☐ Test tree depth, number of estimators
  ☐ Measure latency on actual ESP32 device
  ☐ Verify memory usage fits microcontroller

PHASE 4: Deployment Validation (Week 4-5)
  ☐ Convert model to TensorFlow Lite (edge format)
  ☐ Load on ESP32 and test real-time detection
  ☐ Verify <5ms latency under load
  ☐ Test with multiple sensor nodes
  ☐ Document deployment results

PHASE 5: Documentation (Week 5)
  ☐ Compare RF vs Logistic Regression trade-offs
  ☐ Show speed/accuracy vs Gradient Boosting (offline only)
  ☐ Write deployment guide for ESP32
  ☐ Include resource usage tables (memory, CPU, inference time)
```


---

## 5. Recommended Ensemble Approach

**Best practice: Use multiple models together**

```python
from sklearn.ensemble import VotingClassifier

ensemble = VotingClassifier(
    estimators=[
        ('rf', RandomForestClassifier(n_estimators=300, class_weight='balanced')),
        ('gb', GradientBoostingClassifier(n_estimators=200)),
        ('svm', SVC(kernel='rbf', probability=True, class_weight='balanced'))
    ],
    voting='soft',  # Average probabilities instead of majority vote
    weights=[1, 1.5, 1]  # Weight GB more (highest accuracy)
)

ensemble.fit(X_train, y_train)
y_pred = ensemble.predict(X_test)

# Benefits:
# - Combines strengths of each model
# - More robust to individual model failures
# - Better generalization
```

---

## 6. Expected Performance Baseline

When properly tuned, expect approximately:

| Model | Accuracy | Precision | Recall | F1-Score |
|-------|----------|-----------|--------|----------|
| Logistic Regression | 80% | 70% | 65% | 67% |
| Random Forest | 92% | 85% | 80% | 82% |
| Gradient Boosting | 94% | 88% | 85% | 86% |
| SVM | 91% | 83% | 78% | 80% |
| Isolation Forest | 88% | 75% | 72% | 73% |
| LSTM | 90% | 82% | 80% | 81% |
| **Ensemble (all)** | **95%** | **90%** | **87%** | **88%** |

**Note**: Recall (catching actual Sybils) is more important than Precision in healthcare.

---

## 7. Summary: Why These Models

### **Random Forest**
✓ Fast inference
✓ Robust to outliers
✓ Feature importance built-in
✓ Handles imbalance well
= **Best all-around choice**

### **Gradient Boosting**
✓ Highest accuracy
✓ Sequential error correction
✓ Emphasizes hard cases
= **Best for maximum accuracy**

### **Isolation Forest**
✓ Anomaly-focused
✓ Works without labels
✓ Detects novel attacks
= **Best for unknown threats**

### **LSTM**
✓ Captures temporal patterns
✓ Learns sequence behavior
✓ Better on time-series
= **Best for sequential data**

### **Ensemble**
✓ Combines all strengths
✓ More robust
✓ Better generalization
= **Best for critical systems**

---

## 8. Five-Stage Experiment Plan: Finding the Best Sybil Detection Method

This structured 5-stage pipeline guides you from data validation through to the final best-performing model for your WBAN research.

---

### **STAGE 1: Data Preparation & Baseline Establishment (Week 1)**

**Goal:** Validate dataset quality and establish minimum performance baseline

**What to do:**
1. Create/load your Sybil detection dataset
   - 500+ Normal samples
   - 300+ Sybil samples (multiple attack scenarios)
   - Extract features: pps, rssi_mean, rssi_std, iat_mean, iat_std, etc.
   - Save as `wban_sybil_dataset.csv`

2. Data quality checks
   - Check for missing values
   - Analyze class distribution (80-95% normal, 5-20% sybil?)
   - Analyze feature distributions (outliers?)
   - Split: 70% train, 30% test (stratified)

3. Train **Logistic Regression** (baseline)
   - Easiest model to establish minimum threshold
   - Shows if dataset is learnable at all
   - Fast training and inference

**Models to test:**
- Logistic Regression only (baseline)

**Metrics to calculate:**
- Accuracy, Precision, Recall, F1-score
- ROC-AUC, Confusion Matrix
- Feature importance (coefficients)

**Implementation:**
```python
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score

# Load data
df = pd.read_csv('wban_sybil_dataset.csv')
X = df.drop('label', axis=1)
y = df['label']

# Check data quality
print(f"Class distribution: {y.value_counts()}")
print(f"Missing values: {X.isnull().sum().sum()}")

# Split data
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42, stratify=y
)

# Scale
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Train baseline
lr_baseline = LogisticRegression(class_weight='balanced', max_iter=1000)
lr_baseline.fit(X_train_scaled, y_train)

# Evaluate
y_pred = lr_baseline.predict(X_test_scaled)
y_prob = lr_baseline.predict_proba(X_test_scaled)[:, 1]

print("=== STAGE 1: BASELINE RESULTS ===")
print(classification_report(y_test, y_pred))
print(f"ROC-AUC: {roc_auc_score(y_test, y_prob):.4f}")
print(f"Confusion Matrix:\n{confusion_matrix(y_test, y_pred)}")

# Cross-validation
cv_scores = cross_val_score(lr_baseline, X_train_scaled, y_train, cv=5, scoring='f1')
print(f"Cross-Val F1 (mean±std): {cv_scores.mean():.4f} ± {cv_scores.std():.4f}")
```

**Expected results:**
- F1-score: 70-80% (baseline, not great)
- ROC-AUC: 0.70-0.80
- If significantly lower, dataset may have quality issues

**Go/No-go criteria:**
- ✅ PASS if F1 > 70%: Dataset is learnable, proceed to Stage 2
- ❌ FAIL if F1 < 60%: Debug dataset quality issues first
- ⚠️ WARN if F1 60-70%: Marginal but acceptable, but investigate features

**Deliverables:**
- `stage1_baseline_results.txt` (metrics summary)
- `stage1_feature_analysis.csv` (feature statistics)
- `wban_sybil_dataset.csv` (cleaned dataset)

---

### **STAGE 2: Fast Models Comparison (Week 2)**

**Goal:** Find the best fast model suitable for real-time edge deployment

**What to do:**
Test models optimized for speed while maintaining reasonable accuracy

**Models to test:**
1. Logistic Regression (baseline from Stage 1)
2. Random Forest (fast ensemble)

**Implementation:**
```python
from sklearn.ensemble import RandomForestClassifier
from time import time

# Train Random Forest
print("Training Random Forest...")
start_time = time.time()

rf = RandomForestClassifier(
    n_estimators=300,
    max_depth=15,
    class_weight='balanced',
    random_state=42,
    n_jobs=-1  # Use all cores
)
rf.fit(X_train_scaled, y_train)

train_time = time.time() - start_time
print(f"Training time: {train_time:.2f}s")

# Inference speed
start_time = time.time()
y_pred_rf = rf.predict(X_test_scaled)
y_prob_rf = rf.predict_proba(X_test_scaled)[:, 1]
inference_time = (time.time() - start_time) / len(X_test)
print(f"Inference time per sample: {inference_time*1000:.2f}ms")

# Evaluate
print("=== STAGE 2: FAST MODELS RESULTS ===\n")

# Logistic Regression
print("1. LOGISTIC REGRESSION (Baseline)")
print(f"   F1-score: {f1_score(y_test, lr_baseline.predict(X_test_scaled)):.4f}")
print(f"   Inference: 0.5-1ms per sample")

# Random Forest
print("\n2. RANDOM FOREST")
print(classification_report(y_test, y_pred_rf))
print(f"   Inference: {inference_time*1000:.2f}ms per sample")
print(f"   ROC-AUC: {roc_auc_score(y_test, y_prob_rf):.4f}")

# Feature importance
feature_importance = pd.Series(
    rf.feature_importances_,
    index=X_train.columns
).sort_values(ascending=False)
print(f"\nTop 5 features:\n{feature_importance.head()}")

# Comparison table
comparison_stage2 = pd.DataFrame({
    'Model': ['Logistic Regression', 'Random Forest'],
    'F1-Score': [
        f1_score(y_test, lr_baseline.predict(X_test_scaled)),
        f1_score(y_test, y_pred_rf)
    ],
    'Inference (ms)': [0.8, inference_time*1000],
    'ROC-AUC': [
        roc_auc_score(y_test, lr_baseline.predict_proba(X_test_scaled)[:, 1]),
        roc_auc_score(y_test, y_prob_rf)
    ]
})
print("\n" + "="*60)
print(comparison_stage2.to_string(index=False))
```

**Metrics to calculate:**
- Accuracy, Precision, Recall, F1-score
- ROC-AUC
- Inference time per sample (ms)
- Training time (seconds)
- Feature importance

**Expected results:**
- Logistic Regression: 75-85% F1, 0.5-1ms inference ✓
- Random Forest: 88-92% F1, 2-5ms inference ✓ (2-3x accuracy gain, still fast)

**Go/No-go criteria:**
- ✅ PASS if Random Forest > 85% F1: Proceed to Stage 3
- ✅ PASS if inference < 10ms: Can work for periodic monitoring
- ⚠️ WARN if RF ≈ LR accuracy: Skip to accuracy-focused models in Stage 3

**Decision point:**
- If RF > 90% F1 and < 5ms: **Consider RF as final winner**, skip to Stage 5
- Otherwise: Continue to Stage 3 for accuracy focus

**Deliverables:**
- `stage2_fast_models_comparison.csv` (results table)
- `stage2_feature_importance.pdf` (visualization)
- `stage2_timing_analysis.txt` (speed metrics)

---

### **STAGE 3: Accuracy-Focused Models (Week 3-4)**

**Goal:** Find highest-accuracy model (sacrifice some speed for better accuracy)

**What to do:**
Test advanced models for maximum detection accuracy

**Models to test:**
1. Random Forest (from Stage 2 for reference)
2. Gradient Boosting
3. XGBoost
4. MLP (Neural Network)

**Implementation:**
```python
from sklearn.ensemble import GradientBoostingClassifier
import xgboost as xgb
from sklearn.neural_network import MLPClassifier

print("=== STAGE 3: ACCURACY-FOCUSED MODELS ===\n")

# 1. Gradient Boosting
print("Training Gradient Boosting...")
gb = GradientBoostingClassifier(
    n_estimators=200,
    learning_rate=0.1,
    max_depth=5,
    random_state=42
)
gb.fit(X_train_scaled, y_train)
y_prob_gb = gb.predict_proba(X_test_scaled)[:, 1]

# 2. XGBoost
print("Training XGBoost...")
scale_pos_weight = sum(y_train == 0) / sum(y_train == 1)
xgb_model = xgb.XGBClassifier(
    n_estimators=200,
    learning_rate=0.1,
    max_depth=5,
    scale_pos_weight=scale_pos_weight,
    random_state=42
)
xgb_model.fit(X_train, y_train)  # XGBoost handles scaling internally
y_prob_xgb = xgb_model.predict_proba(X_test)[:, 1]

# 3. MLP
print("Training MLP...")
mlp = MLPClassifier(
    hidden_layer_sizes=(128, 64, 32),
    activation='relu',
    solver='adam',
    max_iter=1000,
    random_state=42,
    early_stopping=True,
    validation_fraction=0.1
)
mlp.fit(X_train_scaled, y_train)
y_prob_mlp = mlp.predict_proba(X_test_scaled)[:, 1]

# Comparison
print("\nACCURACY-FOCUSED MODELS COMPARISON:")
print("="*80)

models_stage3 = {
    'Gradient Boosting': y_prob_gb,
    'XGBoost': y_prob_xgb,
    'MLP': y_prob_mlp,
    'Random Forest': y_prob_rf  # From Stage 2
}

results_stage3 = []
for name, y_probs in models_stage3.items():
    from sklearn.metrics import precision_recall_curve
    
    y_pred_model = (y_probs > 0.5).astype(int)
    f1 = f1_score(y_test, y_pred_model)
    precision = precision_score(y_test, y_pred_model)
    recall = recall_score(y_test, y_pred_model)
    roc_auc = roc_auc_score(y_test, y_probs)
    
    results_stage3.append({
        'Model': name,
        'F1-Score': f1,
        'Precision': precision,
        'Recall': recall,
        'ROC-AUC': roc_auc
    })
    
    print(f"\n{name}:")
    print(f"  F1-Score: {f1:.4f}")
    print(f"  Precision: {precision:.4f}")
    print(f"  Recall: {recall:.4f}")
    print(f"  ROC-AUC: {roc_auc:.4f}")

results_df = pd.DataFrame(results_stage3).sort_values('F1-Score', ascending=False)
print("\n" + "="*80)
print("RANKED RESULTS:")
print(results_df.to_string(index=False))

# Find best
best_model_name = results_df.iloc[0]['Model']
print(f"\n✓ BEST MODEL: {best_model_name}")
```

**Metrics to calculate:**
- Accuracy, Precision, Recall, F1-score
- ROC-AUC
- Confusion matrices for each model
- Inference time per sample

**Expected results:**
- Gradient Boosting: 94-96% F1 ✓
- XGBoost: 95-97% F1 ✓✓ (best)
- MLP: 92-94% F1 ✓
- Random Forest: 91-92% F1 (reference)

**Go/No-go criteria:**
- ✅ PASS if best model > 94% F1: High-accuracy method found
- ✅ PASS if multiple models > 93% F1: Good consistency
- ⚠️ WARN if best < 93% F1: May need feature engineering or more data

**Decision point:**
- If XGBoost significantly > others: **XGBoost winner, move to Stage 5**
- If multiple models similar (within 1-2%): **Test ensemble in Stage 4**
- If results inconsistent: **Validate features, repeat with cross-validation**

**Deliverables:**
- `stage3_accuracy_comparison.csv` (detailed metrics)
- `stage3_roc_curves.pdf` (visualization)
- `stage3_best_model.pkl` (saved best model)

---

### **STAGE 4: Ensemble & Optimization (Week 4-5)**

**Goal:** Combine best models into ensemble for maximum performance and robustness

**What to do:**
Build ensemble from top-performing models and fine-tune hyperparameters

**Models to test:**
1. Individual best models (from Stage 3)
2. Soft Voting Ensemble (combines probabilities)
3. Stacking (meta-learner approach)

**Implementation:**
```python
from sklearn.ensemble import VotingClassifier
from sklearn.model_selection import GridSearchCV

print("=== STAGE 4: ENSEMBLE & OPTIMIZATION ===\n")

# Get top 3 models from Stage 3
# Assuming: XGBoost > Gradient Boosting > MLP

# 1. Soft Voting Ensemble
print("Creating Soft Voting Ensemble...")
voting_ensemble = VotingClassifier(
    estimators=[
        ('xgb', xgb_model),
        ('gb', gb),
        ('mlp', mlp)
    ],
    voting='soft',  # Average probabilities
    weights=[1.5, 1.2, 1.0]  # Weight best models more
)
voting_ensemble.fit(X_train, y_train)
y_prob_voting = voting_ensemble.predict_proba(X_test)[:, 1]

# 2. Hyperparameter tuning on best model (XGBoost)
print("\nTuning XGBoost hyperparameters...")
param_grid = {
    'max_depth': [4, 5, 6],
    'learning_rate': [0.05, 0.1, 0.15],
    'n_estimators': [150, 200, 250]
}

grid_search = GridSearchCV(
    xgb.XGBClassifier(scale_pos_weight=scale_pos_weight, random_state=42),
    param_grid,
    cv=5,
    scoring='f1',
    n_jobs=-1
)
grid_search.fit(X_train, y_train)
xgb_optimized = grid_search.best_estimator_
y_prob_xgb_opt = xgb_optimized.predict_proba(X_test)[:, 1]

print(f"Best parameters: {grid_search.best_params_}")
print(f"Best CV F1-score: {grid_search.best_score_:.4f}")

# Final comparison
print("\n" + "="*80)
print("STAGE 4: ENSEMBLE & OPTIMIZED RESULTS")
print("="*80)

final_models = {
    'XGBoost (Optimized)': y_prob_xgb_opt,
    'Voting Ensemble (XGB+GB+MLP)': y_prob_voting,
    'XGBoost (Original)': y_prob_xgb,
    'Gradient Boosting': y_prob_gb
}

results_stage4 = []
for name, y_probs in final_models.items():
    y_pred_model = (y_probs > 0.5).astype(int)
    f1 = f1_score(y_test, y_pred_model)
    precision = precision_score(y_test, y_pred_model)
    recall = recall_score(y_test, y_pred_model)
    roc_auc = roc_auc_score(y_test, y_probs)
    
    results_stage4.append({
        'Model': name,
        'F1-Score': f1,
        'Precision': precision,
        'Recall': recall,
        'ROC-AUC': roc_auc
    })

results_stage4_df = pd.DataFrame(results_stage4).sort_values('F1-Score', ascending=False)
print(results_stage4_df.to_string(index=False))

best_stage4 = results_stage4_df.iloc[0]
print(f"\n✓ BEST MODEL (Stage 4): {best_stage4['Model']}")
print(f"  F1-Score: {best_stage4['F1-Score']:.4f}")
```

**Models to compare:**
- XGBoost (original)
- XGBoost (hyperparameter tuned)
- Voting Ensemble (soft combination)

**Metrics to calculate:**
- Accuracy, Precision, Recall, F1-score
- ROC-AUC
- Threshold analysis (precision-recall curves)
- Cross-validation stability

**Expected results:**
- XGBoost Optimized: 96-97% F1 ✓✓
- Ensemble: 96-98% F1 ✓✓✓ (best, most robust)
- Tuning typically +0.5-1% improvement

**Go/No-go criteria:**
- ✅ PASS if best > 95% F1: Publication-ready accuracy
- ✅ PASS if Cross-Val stable (low std): Consistent performance
- ⚠️ WARN if Ensemble ≈ Individual models: Ensemble not adding value

**Decision point:**
- If Ensemble > 96%: **Ensemble is final winner**
- If XGBoost tuned > 95.5%: **XGBoost is final winner (simpler)**
- Either way: **Proceed to Stage 5 for validation**

**Deliverables:**
- `stage4_ensemble_comparison.csv` (all results)
- `stage4_hyperparameter_tuning.txt` (grid search results)
- `stage4_best_model_tuned.pkl` (saved optimized model)
- `stage4_threshold_analysis.pdf` (precision-recall curves)

---

### **STAGE 5: Final Validation & Winner Selection (Week 5)**

**Goal:** Validate final best model on independent test set and compare all winners

**What to do:**
Perform rigorous validation with cross-validation, confidence intervals, and final comparison

**Implementation:**
```python
from sklearn.model_selection import StratifiedKFold, cross_validate
import matplotlib.pyplot as plt

print("=== STAGE 5: FINAL VALIDATION & WINNER SELECTION ===\n")

# Use entire dataset for final cross-validation
kfold = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

# Candidates (best from each stage)
candidates = {
    'Random Forest (Stage 2)': rf,
    'XGBoost (Stage 3)': xgb_model,
    'XGBoost Optimized (Stage 4)': xgb_optimized,
    'Ensemble (Stage 4)': voting_ensemble
}

print("CROSS-VALIDATION ANALYSIS (5-Fold):")
print("="*80)

cv_results = []

for model_name, model in candidates.items():
    print(f"\nTesting {model_name}...")
    
    # Cross-validation with multiple metrics
    cv_scores = cross_validate(
        model, X, y,
        cv=kfold,
        scoring=['accuracy', 'precision', 'recall', 'f1', 'roc_auc'],
        n_jobs=-1
    )
    
    # Calculate statistics
    f1_mean = cv_scores['test_f1'].mean()
    f1_std = cv_scores['test_f1'].std()
    auc_mean = cv_scores['test_roc_auc'].mean()
    precision_mean = cv_scores['test_precision'].mean()
    recall_mean = cv_scores['test_recall'].mean()
    
    cv_results.append({
        'Model': model_name,
        'F1 (mean±std)': f"{f1_mean:.4f} ± {f1_std:.4f}",
        'ROC-AUC': f"{auc_mean:.4f}",
        'Precision': f"{precision_mean:.4f}",
        'Recall': f"{recall_mean:.4f}"
    })
    
    print(f"  F1: {f1_mean:.4f} ± {f1_std:.4f}")
    print(f"  ROC-AUC: {auc_mean:.4f}")
    print(f"  Precision: {precision_mean:.4f}")
    print(f"  Recall: {recall_mean:.4f}")

cv_results_df = pd.DataFrame(cv_results)
print("\n" + "="*80)
print("CROSS-VALIDATION SUMMARY:")
print(cv_results_df.to_string(index=False))

# Final winner
print("\n" + "="*80)
print("FINAL RECOMMENDATIONS:")
print("="*80)

print("""
Based on all 5 stages of experimentation:

ACCURACY WINNER: Ensemble (Voting) or XGBoost Optimized
├─ F1-Score: 96-98%
├─ ROC-AUC: 0.96-0.98
├─ Use when: Maximum accuracy matters (hospital deployment)
└─ Inference: 30-50ms per prediction

SPEED-ACCURACY BALANCE: Random Forest
├─ F1-Score: 91-92%
├─ ROC-AUC: 0.92-0.94
├─ Inference: 2-5ms per prediction
├─ Use when: Real-time ESP32 deployment
└─ Recommendation: Preferred for edge devices

RECOMMENDATION FOR YOUR RESEARCH:
├─ If need highest accuracy: Use Ensemble
├─ If need real-time: Use Random Forest
└─ If unsure: Start with Random Forest, upgrade to Ensemble if needed
""")

# Create final comparison table
print("\nFINAL MODEL COMPARISON TABLE:")
print("="*80)

final_comparison = pd.DataFrame({
    'Metric': ['F1-Score', 'ROC-AUC', 'Inference (ms)', 'Interpretable', 'Training Time', 'Best Use Case'],
    'Random Forest': ['91-92%', '0.92-0.94', '2-5', '✓✓✓', 'Fast', 'Real-time/Edge'],
    'XGBoost Opt': ['96-97%', '0.96-0.97', '20-50', '✓✓', 'Medium', 'High Accuracy'],
    'Ensemble': ['96-98%', '0.96-0.98', '30-50', '✓', 'Slow', 'Maximum Accuracy']
})

print(final_comparison.to_string(index=False))

# Save everything
print("\n" + "="*80)
print("DELIVERABLES CREATED:")
print("="*80)
print("""
stage5_cv_analysis.csv - Cross-validation results for all models
stage5_final_comparison.txt - Comprehensive comparison summary
stage5_winner_model.pkl - Final best model (saved)
stage5_experiment_summary.pdf - Visual summary and recommendations
""")
```

**Validation checklist:**
- ✅ 5-fold cross-validation analysis
- ✅ Confidence intervals (mean ± std)
- ✅ Comparison across all stages
- ✅ Feature importance analysis
- ✅ Confusion matrices and ROC curves
- ✅ Inference time benchmarking

**Expected final results:**
```
WINNER COMPARISON:
┌─────────────────────┬──────────┬──────────┬─────────────┐
│ Model               │ F1-Score │ ROC-AUC  │ Inference   │
├─────────────────────┼──────────┼──────────┼─────────────┤
│ Ensemble (Best)     │ 97.5%    │ 0.975    │ 40ms        │
│ XGBoost Optimized   │ 96.8%    │ 0.968    │ 25ms        │
│ Random Forest       │ 91.8%    │ 0.918    │ 3ms         │
│ Logistic Regression │ 78.2%    │ 0.782    │ 0.8ms       │
└─────────────────────┴──────────┴──────────┴─────────────┘
```

**Final decision criteria:**
- **✅ Accuracy Focus**: Choose Ensemble (97%+ F1)
- **✅ Speed-Accuracy Balance**: Choose XGBoost (96%+ F1, 25ms)
- **✅ Real-time Edge**: Choose Random Forest (92% F1, 3ms)

**Deliverables:**
- `stage5_cv_summary.csv` (all cross-validation results)
- `stage5_final_winner.txt` (recommendation and justification)
- `stage5_best_model.pkl` (saved final model)
- `experiment_complete_report.pdf` (full 5-stage summary)

---

### **Quick Reference: 5-Stage Timeline**

```
WEEK 1: Data Prep & Baseline
└─ Logistic Regression baseline → F1: 78%

WEEK 2: Fast Models
├─ Random Forest ↓ → F1: 91% ✓
└─ Winner comparison with LR

WEEK 3-4: Accuracy Focus
├─ Gradient Boosting → F1: 95%
├─ XGBoost → F1: 96% ✓
├─ MLP → F1: 93%
└─ Ranked comparison

WEEK 4-5: Ensemble & Tuning
├─ XGBoost hyperparameter tuning → F1: 96.8% ✓
├─ Voting Ensemble → F1: 97.5% ✓✓
└─ Final selection

WEEK 5: Validation & Final Report
├─ 5-fold cross-validation
├─ Final winner announcement
└─ Research document complete

FINAL WINNER: Ensemble or XGBoost (depending on requirements)
```

---

### **Decision Tree: Which Model to Choose?**

```
START: Choose Your Best Sybil Detection Model

├─ Is model for ESP32 real-time deployment?
│  ├─ YES → Random Forest
│  │   ├─ F1: 91-92%
│  │   ├─ Inference: 3ms
│  │   └─ Use for: ESP32 edge devices, wearables
│  └─ NO → Continue
│
├─ Is accuracy the #1 priority?
│  ├─ YES → Ensemble or XGBoost
│  │   ├─ F1: 96-98%
│  │   ├─ ROC-AUC: 0.96-0.98
│  │   └─ Use for: Hospital deployments, research papers
│  └─ NO → Continue
│
├─ Do you need model interpretability?
│  ├─ YES → XGBoost + feature importance
│  │   └─ Good balance: 96% accuracy + explainability
│  └─ NO → Ensemble
│      └─ Maximum accuracy: 97-98%
│
└─ FINAL CHOICE → Your Model Selected!
```

---

### **How to Execute This Plan**

**Setup (One-time):**
```bash
# Install required packages
pip install scikit-learn xgboost pandas numpy matplotlib seaborn

# Create experiment directory
mkdir wban_sybil_experiments
cd wban_sybil_experiments
```

**For each stage:**
1. Copy the provided code
2. Replace `wban_sybil_dataset.csv` with your data
3. Run the stage code
4. Save results to `stage{N}_results/`
5. Review Go/No-go criteria
6. Proceed to next stage

**Final output:**
- Best model file: `winner_model.pkl`
- Summary report: `EXPERIMENT_SUMMARY.pdf`
- All metrics: `final_comparison_table.csv`

---

## Next Steps

1. **Start with Random Forest** - Good baseline, understand features
2. **Try Gradient Boosting** - If accuracy insufficient
3. **Add Isolation Forest** - For unseen attack detection
4. **Implement LSTM** - If temporal analysis helps
5. **Build Ensemble** - For production deployment

See `2_ML_METHODS_AND_APPROACHES.md` for detailed methodology.
